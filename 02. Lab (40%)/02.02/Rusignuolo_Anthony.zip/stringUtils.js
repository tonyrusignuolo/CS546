function isProperString(arg)
{
	if (arg == undefined)
	{
		throw "string is undefined";
	}
	if (typeof arg !== "string")
	{
		throw "not a string";
	}
}

function checkIsProperInt(arg)
{
	if (typeof arg !== "number")
	{
		throw "arg is not a number"
	}
}

module.exports = {
	description: "string utilities",

	capitalize: (string) =>
	{
		// Given a string, capitalize the first letter and lowercase the remaining characters.
		isProperString(string);
		string.toLowerCase();
		string[0].toUpperCase();
		return string;
	},

	repeat: (string, num) =>
	{
		// Given string and num, repeat the string num amount of times.
		isProperString(string);
		checkIsProperInt(num);
		if (num <= 0)
		{
			throw "num is not positive";
		}
		let newString = "";
		for (let i = 0; i < num; i++)
		{
			newString += string;
		}
		return newString;
	},

	countChars: (string) =>
	{
		// Return an object that has the mapping of a character and the amount of times it appears in a string. Hint: You may use a function you have written already.
		isProperString(string);
		let object = {};
		for (let i = 0; i < string.length; i++)
		{
			if (object[string[i]])
			{
				object[string[i]] += 1;
			}
			else
			{
				object[string[i]] = 1;
			}
		}
		return object;
	}
}