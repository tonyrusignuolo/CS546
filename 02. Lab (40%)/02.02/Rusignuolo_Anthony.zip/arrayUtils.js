function checkisProperArray(arg)
{
	if (arg == undefined)
	{
		throw "array is undefined";
	}
	if (Array.isArray(arg) != true)
	{
		throw "not an array";
	}
	else if (arg.length == 0)
	{
		throw "array is empty"
	}
}

function checkIsProperInt(arg)
{
	if (typeof arg !== "number")
	{
		throw "arg is not a number"
	}
}

module.exports = {
	description: "array utilities",
	
	head: (array) =>
	{
		// returns the first element of the array
		checkisProperArray(array);
		return array[0];
	},

	last: (array) =>
	{
		// returns the last element of the array
		checkisProperArray(array);
		return array[array.length - 1];
	},

	remove: (array, index) =>
	{
		// removes the element at the specified index of the array and returns the new array
		checkisProperArray(array);
		if (index >= array.length)
		{
			throw "index is out of bounds";
		}
		array.splice(index,1);
		return array;
	},

	range: (end, value = null) =>
	{
		// Creates a new numbered array starting at 0 increasing by one up to, but not including the end argument. The value argument is optional, but when specified each element will be set to that value.
		checkIsProperInt(end);
		if (end <= 0)
		{
			throw "end is out of range";
		}
		let array = [];
		for (let i = 0; i <= end; i++)
		{
			if (value)
			{
				array.push(value);
			}
			else
			{
				array.push(i);
			}
		}
		return array;
	},

	countElements: (array) =>
	{
		// Will return an object with the count of each unique element in the array.
		checkisProperArray(array);
		object = {}
		for (let i = 0; i < array.length; i++)
		{
			if (object[array[i]])
			{
				object[array[i]] += 1;
			}
			else
			{
				object[array[i]] = 1;
			}
		}
		return object;
	},

	isEqual: (arrayOne, arrayTwo) =>
	{
		// Given two arrays, check if they are equal in terms of size and elements and return a boolean. Order of the items in the elements matters when comparing equality.
		checkisProperArray(arrayOne);
		checkisProperArray(arrayTwo);
		if (arrayOne.length != arrayTwo.length)
		{
			return false;
		}
		else
		{
			for (let i = 0; i < arrayOne.length; i++)
			{
				if (arrayOne[i] != arrayTwo[i])
				{
					return false;
				}
			}
			return true;
		}
	}
}